﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ResidualCenter.Models.ViewModels
{
    public class EmployeeViewModel
    {
        public class CloseServices
        {
            public int ID { get; set; }
            public int Quantity { get; set; }
            //public int EmployeeListID { get; set; }
        }
    }
}